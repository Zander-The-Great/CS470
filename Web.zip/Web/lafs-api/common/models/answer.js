'use strict';

module.exports = function(Answer) {

};
