'use strict';

module.exports = function(Question) {

};
